const JSON_DECODE_ERROR = 'Podczas dekodowania odpowiedzi serwera wystąpił błąd.';
const HTTP_RESPONSE_CODE = 'Kod odpowiedzi HTTP:';

chrome.storage.onChanged.addListener( (storageObject, storageArea) => {
	if (storageArea === 'session') {
		if ('message' in storageObject && 'newValue' in storageObject.message) {
			toastMessage(storageObject.message.newValue);
			chrome.storage.session.remove('message');
		}
	}
});

async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(result); 
    });
  });
}

async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}

window.addEventListener('DOMContentLoaded', async () => {
	console.log('Załadowano skrypt optionsPage');
	chrome.storage.session.get(['message']).then(result => {
		if (result.message !== undefined) {
			toastMessage(result.message);
			chrome.storage.session.remove('message');
		}
	});

  const redirectUrl = chrome.identity.getRedirectURL('salescenter');
  document.getElementById('chromeExtensionRedirectURL').innerText = redirectUrl;

	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['allegroAPIClientId', 'allegroAPIClientSecret', 'systemNotifications']);
	} catch (error) {
		toastMessage(`Błąd! W trakcie próby odczytu danych wystąpił błąd. ${error.message}`);
		return;
	}

	if (readedValue.allegroAPIClientId !== undefined && readedValue.allegroAPIClientSecret !== undefined) {	
		const allegroAPIClientIdText = document.getElementById('allegroAPIClientIdText');
		allegroAPIClientIdText.value = readedValue.allegroAPIClientId;
		allegroAPIClientIdText.addEventListener('paste', (e) => {
			e.preventDefault();
			let paste = e.clipboardData.getData('text');
			let patternClientId = /[0-9a-f]{32}/g;
			if (patternClientId.test(paste)) {
				e.target.value = paste;
				const inputsValidity = document.getElementById('allegroAPIClientSecretText').checkValidity();
				document.getElementById('allegroAPISaveButton').disabled = !inputsValidity;
				document.getElementById('allegroAPILoginButton').disabled = true;
			}	
		});
		allegroAPIClientIdText.addEventListener('input', () => {
			const inputsValidity = document.getElementById('allegroAPIClientIdText').checkValidity() && document.getElementById('allegroAPIClientSecretText').checkValidity();
			document.getElementById('allegroAPISaveButton').disabled = !inputsValidity;
			document.getElementById('allegroAPILoginButton').disabled = true;
		});

		const allegroAPIClientSecretText = document.getElementById('allegroAPIClientSecretText');
		allegroAPIClientSecretText.value = readedValue.allegroAPIClientSecret;
		allegroAPIClientSecretText.addEventListener('paste', (e) => {
			e.preventDefault();
			let paste = e.clipboardData.getData('text');
			let patternClientSecret = /[0-9a-zA-Z]{64}/g;
			if (patternClientSecret.test(paste)) {
				e.target.value = paste;
				const inputsValidity = document.getElementById('allegroAPIClientIdText').checkValidity();
				document.getElementById('allegroAPISaveButton').disabled = !inputsValidity;
				document.getElementById('allegroAPILoginButton').disabled = true;
			}	
		});
		allegroAPIClientSecretText.addEventListener('input', () => {
			const inputsValidity =  document.getElementById('allegroAPIClientIdText').checkValidity() && document.getElementById('allegroAPIClientSecretText').checkValidity();
			document.getElementById('allegroAPISaveButton').disabled = !inputsValidity;
			document.getElementById('allegroAPILoginButton').disabled = true;
		});

	}
	const allegroAPISaveButton = document.getElementById('allegroAPISaveButton');
	allegroAPISaveButton.addEventListener('click', allegroAPISaveButtonClick);
	const allegroAPILoginButton = document.getElementById('allegroAPILoginButton');
	allegroAPILoginButton.addEventListener('click', allegroAPILoginButtonClick);
	if (allegroAPIClientIdText.checkValidity() && allegroAPIClientIdText.value !== '' && allegroAPIClientSecretText.checkValidity && allegroAPIClientSecretText.value !== '') {
		document.getElementById('allegroAPILoginButton').disabled = false;
	}

	const systemNotificationsCheckbox = document.getElementById('systemNotificationsCheckbox');
	systemNotificationsCheckbox.checked = readedValue.systemNotifications;
	systemNotificationsCheckbox.addEventListener('change', async (e) => {
		try {
			await saveDataToLocalStorage({ systemNotifications: e.target.checked });
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić ustawień powiadomień. ${error.message}`);
			return Promise.reject(false);
		}
		toastMessage('Zapisano');
	});

  try {
    response = await sendMessage({ action: 'checkSchedule' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    return Promise.reject(`Podczas sprawdzania stanu automatycznego pobierania wiadomości wystąpił błąd. ${error.message}`);
  }
  let workingStateInfo = document.getElementById('workingStateInfo');
  if (!response.result) {
    workingStateInfo.innerHTML = /*HTML*/ `<div class="alert alert-danger" role="alert"><h4 class="alert-heading">Automatyczne sprawdzanie wiadomości jest wyłączone.</h4><p>Upewnij się że uzupełniłeś dane widoczne wyżej, zapisałeś je i zalogowałeś się. Po wykonaniu tych czynności (lub jeśli zrobiłeś to już wcześniej) wejdź na stronę Sales Center lub jeśli masz ją już otwartą - odśwież ją celem włączenia automatycznego trybu pracy.</p></div>`;
  } else {
    workingStateInfo.innerHTML = /*HTML*/ `<div class="alert alert-success" role="alert"><h4 class="alert-heading">Automatyczne sprawdzanie wiadomości jest włączone.</h4><p>Co minutę nastąpi sprawdzanie czy w centrum wiadomości lub w dyskusjach są nowe wiadomości. Informację o wiadomościach otrzymasz na wszystkich otwarych stronach Sales Center w postaci wyróżnionej na czerwono ikony oraz zostanie wyświetlone chwilowe wyskakujące powiadomienie. W przypadku wystąpienia błędu informacja będzie wyświetlona na aktywnej stronie Sales Center do czasu najechania kursorem na powiadomienie, jeżeli nie masz aktywnej strony Sales Center w momencie wystąpienia błędu, wyświetlone zostanie powiadomienie w systemowym centrum powiadomień.</p></div>`;
  }
});

async function allegroAPISaveButtonClick() {
	try {
		const response = await sendMessage({ action: 'allegroAPISave', clientId: document.getElementById('allegroAPIClientIdText').value, clientSecret: document.getElementById('allegroAPIClientSecretText').value });
    if (!response.success) throw new Error(response.result);
		document.getElementById('allegroAPISaveButton').disabled = true;
		document.getElementById('allegroAPILoginButton').disabled = !response.result;
    let workingStateInfo = document.getElementById('workingStateInfo');
    workingStateInfo.innerHTML = /*HTML*/ `<div class="alert alert-danger" role="alert"><h4 class="alert-heading">Automatyczne sprawdzanie wiadomości jest wyłączone.</h4><p>Upewnij się że uzupełniłeś dane widoczne wyżej, zapisałeś je i zalogowałeś się. Po wykonaniu tych czynności (lub jeśli zrobiłeś to już wcześniej) wejdź na stronę Sales Center lub jeśli masz ją już otwartą - odśwież ją celem włączenia automatycznego trybu pracy.</p></div>`;
  
		toastMessage('Zapisano. Teraz kliknij przycisk "Zaloguj"');
	} catch (error) {
		toastMessage(`Błąd! Podczas zapisu parametrów Client ID i Client Secret wystąpił błąd. ${error instanceof Error ? error.message : error}`);
	};
}

async function allegroAPILoginButtonClick() {
	let loginData;
	try {
		loginData = await readDataFromLocalStorage(['allegroAPIClientId', 'allegroAPIClientSecret']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytu danych wystąpił błąd. ${error.message}`);
		return;
	}
	
	if (loginData['allegroAPIClientId'] === undefined || loginData['allegroAPIClientSecret'] === undefined) {
		toastMessage('Błąd! Nie znaleziono danych wymaganych do logowania.');
		return;
	}
	async function login(count = 3) {
		let params = {
			scopes: ['allegro:api:profile:read', 'allegro:api:messaging', 'allegro:api:disputes']
		}

		let fetchResponse;
		let fetchData;
		let response;	
	
    const redirectUri = document.getElementById('chromeExtensionRedirectURL').innerText;
    let redirectUrl;
    try {
      redirectUrl = await chrome.identity.launchWebAuthFlow({ 'url': `https://allegro.pl/auth/oauth/authorize?response_type=code&client_id=${document.getElementById('allegroAPIClientIdText').value}&redirect_uri=${redirectUri}&scope=${params.scopes.join(' ')}&prompt=confirm`, 'interactive': true, 'abortOnLoadForNonInteractive': false, timeoutMsForNonInteractive: 10000 });
    } catch (error) {
      if (error.message === 'The user did not approve access.') return Promise.reject('Proces logowania nie został zakończony.');
    }

    if (redirectUrl !== undefined) {
      const code = redirectUrl.substring(redirectUrl.indexOf('code=') + 5);
      try {
        fetchResponse = await fetch(`https://allegro.pl/auth/oauth/token?grant_type=authorization_code&code=${code}&redirect_uri=${redirectUri}`, {
          method: 'POST',
          headers: {
            'Authorization': `Basic ${btoa(loginData['allegroAPIClientId'] + ':' + loginData['allegroAPIClientSecret'])}`
          },		
        });
      } catch (error) {
        return Promise.reject(`Spróbuj ponownie później. ${HTTP_RESPONSE_CODE} ${fetchResponse.status}`);
      }
      if (fetchResponse.status === 200) {
        try {
          fetchData = await fetchResponse.json();
        } catch (error) {
          return Promise.reject(`${JSON_DECODE_ERROR} ${error.message}`);
        }

        if (fetchData.access_token !== undefined && fetchData.refresh_token !== undefined) {
          try {
            await saveDataToLocalStorage({ allegroAccessToken: fetchData.access_token, allegroRefreshToken: fetchData.refresh_token });
          } catch (error) {
            return Promise.reject(`Podczas zapisywania nowych tokenów dostępowych wystąpił błąd. ${error.message}`);
          }
          
          async function getLoggedUsername(count = 3) {
            try {
              fetchResponse = await fetch('https://api.allegro.pl/me', {
                method: 'GET',
                headers: {
                  'Authorization': `Bearer ${fetchData.access_token}`,
                  'Content-Type': 'application/vnd.allegro.public.v1+json',
                  'Accept': 'application/vnd.allegro.public.v1+json'
                }
              });
            } catch (error) {
              if (--count) {	
                toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
                const delay = t => new Promise(resolve => setTimeout(resolve, t));
                await delay(5000);
                return await getLoggedUsername(count);
              } else return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. ${error.message}`);
            } 

            if (fetchResponse.status === 200) {
              try {
                fetchData = await fetchResponse.json();
              } catch (error) {
                return Promise.reject(`${JSON_DECODE_ERROR} ${error.message}`);
              }
              if (fetchData.login !== undefined) return Promise.resolve(fetchData.login);
              else return Promise.reject('W odpowiedzi serwera nie otrzymano nazwy zalogowanego użytkownika.');
            } else {
              if (fetchResponse.status === 403) return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
              else if (fetchResponse.status !== 401) {
                if (--count) {
                  const delay = t => new Promise(resolve => setTimeout(resolve, t));
                  await delay(5000);
                  return await getLoggedUsername(count);	
                } else return Promise.reject(`${HTTP_RESPONSE_CODE} ${fetchResponse.status}`);													
              }	else {
                if (--count) {
                  try {
                    response = await sendMessage({ action: 'refreshAllegroAccessToken' });
                    if (!response.success) throw new Error(response.result);
                  } catch (error) {
                    return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error.message}`);
                  }
                  fetchData.access_token = response.result;
                  return await getLoggedUsername(count);
                } else {
                  return Promise.reject('Nie udało się odświeżyć tokena dostępowego.');
                }		
              }
            }												
          }

          try {
            const username = await getLoggedUsername();
            return Promise.resolve(`Zalogowano jako użytkownik ${username}. Otwórz stronę Sales Center lub odśwież jeśli masz ją otwartą aby aktywować automatyczne sprawdzanie wiadomości.`);
          } catch (error) {
            return Promise.reject(`Nie udało się pobrać nazwy zalogowanego użytkownika. ${error}`);
          }															
        }					
      } else if (fetchResponse.status === 403) {
        return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
      }	else {
        if (--count) {
          const delay = t => new Promise(resolve => setTimeout(resolve, t));
          delay(5000)
          return await login(count);
        } else return Promise.reject(`Spróbuj ponownie później. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
      }	
    } 	
	}

	try {
		const result = await login();
		toastMessage(result);
	} catch (error) {
		toastMessage(`Błąd! ${error}`);
	}
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	if (request.action === 'showMessageOnOptionsPage') {
		toastMessage(request.message);
	}
});
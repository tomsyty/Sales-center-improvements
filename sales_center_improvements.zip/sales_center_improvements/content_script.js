async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}

async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(result); 
    });
  });
}

async function saveDataToSessionStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.session.set(data, () => {
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(true); 
    });
  });
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: 'backgroundFetch',
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(response.result);
      }
    });
  });
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt salesCenterImprovements');	
  let toast;
  let disputeId;
  let readedValue;
  let response;
  let sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  let environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  const disputeHrefRegex = new RegExp(`https:\/\/salescenter\.allegro\.com${sandbox === 'Sandbox' ? '\.allegrosandbox\.pl' : ''}\/discussions-with-buyers\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}`);
  const disputeIdRegex = new RegExp(`(?<=https:\/\/salescenter\.allegro\.com${sandbox === 'Sandbox' ? '\.allegrosandbox\.pl' : ''}\/discussions-with-buyers\/)[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}`);
  toast = document.getElementById('aeToast');
  if (toast === null) {
    toast = document.createElement('div');
    toast.id = 'aeToast';
    toast.classList.add('aeToastHidden');
    document.body.appendChild(toast);
  }

  if (window.location.href.startsWith(`https://salescenter.allegro.com${environment}/message-center/messages/`)) {
    const delay = t => new Promise(resolve => setTimeout(resolve, t));
    await delay(5000);
    try {
      response = await sendMessage( { action: 'checkForUnreadMessages', silent: true });
      if (!response.success) throw new Error(response.result);
    } catch (error) {
      toastMessage(`Błąd! ${error instanceof Error ? error.message : error}`);
    }
  } else if (window.location.href.search(disputeHrefRegex) !== -1) {
    disputeId = disputeIdRegex.exec(window.location.href);
    try {
      readedValue = await readDataFromLocalStorage([`dispute_${disputeId}`]);
    } catch (error) {
      toastMessage(`Błąd! Nie udało się sprawdzić statystyk dotyczących dyskusji ${disputeId}.`);
    }
    if (readedValue[`dispute_${disputeId}`] !== undefined) {
      if (readedValue[`dispute_${disputeId}`].unread === true) {
        readedValue[`dispute_${disputeId}`].unread = false;
        try {
          await saveDataToLocalStorage({ [`dispute_${disputeId}`]: readedValue[`dispute_${disputeId}`] });
          toastMessage('Dyskusja oznaczona jako przeczytana.');
        } catch (error) {
          toastMessage(`Błąd! Nie udało się oznaczyć dyskusji ${disputeId} jako przeczytanej.`);
        }
      }
    }
  } else if (window.location.href.startsWith(`https://salescenter.allegro.com${environment}/my-sales`)) {
    toastMessage('Sprawdzanie wiadomości');
    try {
      response = await sendMessage( { action: 'checkForUnreadMessages', silent: false });
      if (!response.success) throw new Error(response.result);
    } catch (error) {
      toastMessage(`Błąd! ${error instanceof Error ? error.message : error}`);
    }
  } 
  
  let messageIcons, drawerMessageIcon, topDiscussionIcon, topMessageIcon, drawerOrdersAndReturnsIcon;
  try {
    [ messageIcons, topDiscussionIcon, drawerOrdersAndReturnsIcon ] = await waitForMenu();
  } catch (error) {
    toastMessage(`Błąd! ${error instanceof Error ? error.message : error}`);
    return Promise.reject(false);
  }

  topMessageIcon = messageIcons[0];
  drawerMessageIcon = messageIcons[1];

  const drawer = document.querySelector('header[data-testid="drawer-menu"]');
  drawer.addEventListener('transitionend', (e) => {
    if (e.propertyName === 'width') {
      const discussionMenu = drawer.querySelector('a[href="/discussions-with-buyers"]');
      let discussionIconBadge = drawer.querySelector('#discussionIconBadge');
      if (discussionIconBadge) discussionIconBadge.remove();
      if (parseInt(drawerOrdersAndReturnsIcon.dataset.unread)) {
        discussionIconBadge = document.createElement('div');
        discussionIconBadge.id = 'discussionIconBadge';
        discussionIconBadge.className = topDiscussionIcon.nextElementSibling.className;
        discussionIconBadge.classList.remove('mp7g_f6');
        discussionIconBadge.textContent = drawerOrdersAndReturnsIcon.dataset.unread;
      }

      if (drawer.offsetWidth > 100) {
        if (discussionMenu) {
          if (drawerOrdersAndReturnsIcon.classList.contains('unread')) {
            drawerOrdersAndReturnsIcon.classList.remove('unread');
            discussionMenu.classList.add('unread');
          }
          if (parseInt(drawerOrdersAndReturnsIcon.dataset.unread)) {
            discussionIconBadge.classList.add('badgeMoved'); 
            discussionMenu.before(discussionIconBadge);
          }
        } else {
          if (drawerOrdersAndReturnsIcon.dataset.unread !== undefined) {
            drawerOrdersAndReturnsIcon.classList.add('unread');
            if (parseInt(drawerOrdersAndReturnsIcon.dataset.unread)) {
              drawerOrdersAndReturnsIcon.firstChild.firstChild.after(discussionIconBadge);
            }
          }
        }
      } else {
        if (drawerOrdersAndReturnsIcon.dataset.unread !== undefined) {
          drawerOrdersAndReturnsIcon.classList.add('unread');
          if (parseInt(drawerOrdersAndReturnsIcon.dataset.unread)) {
            drawerOrdersAndReturnsIcon.firstChild.firstChild.after(discussionIconBadge);
          }
        }
      }
    }
  });

  const mutationObserver = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
      if (mutation.type === 'attributes' && mutation.attributeName === 'aria-expanded') {
        const isExpanded = drawerOrdersAndReturnsIcon.getAttribute('aria-expanded') === 'true';

        let discussionIconBadge = drawer.querySelector('#discussionIconBadge');
        if (discussionIconBadge) discussionIconBadge.remove();
        if (parseInt(drawerOrdersAndReturnsIcon.dataset.unread)) {
          discussionIconBadge = document.createElement('div');
          discussionIconBadge.id = 'discussionIconBadge';
          discussionIconBadge.className = topDiscussionIcon.nextElementSibling.className;
          discussionIconBadge.classList.remove('mp7g_f6');
          discussionIconBadge.textContent = drawerOrdersAndReturnsIcon.dataset.unread;
        }

        if (isExpanded) {
          const parent = drawerOrdersAndReturnsIcon.parentElement;
          const discussionMenu = parent.querySelector('a[href="/discussions-with-buyers"]');
          if (drawerOrdersAndReturnsIcon.classList.contains('unread')) {
            drawerOrdersAndReturnsIcon.classList.remove('unread');
            discussionMenu.classList.add('unread');
          } 
          if (parseInt(drawerOrdersAndReturnsIcon.dataset.unread)) {
            discussionIconBadge.classList.add('badgeMoved');
            discussionMenu.before(discussionIconBadge); 
          }      
        } else {
          if (drawerOrdersAndReturnsIcon.dataset.unread !== undefined) {
            drawerOrdersAndReturnsIcon.classList.add('unread');
            drawerOrdersAndReturnsIcon.querySelector('p').style.setProperty('background', 'none', 'important');
            if (parseInt(drawerOrdersAndReturnsIcon.dataset.unread)) drawerOrdersAndReturnsIcon.firstChild.firstChild.after(discussionIconBadge); 
          }
        }
      }
    });
  });
  mutationObserver.observe(drawerOrdersAndReturnsIcon, { attributes: true, attributeFilter: ['aria-expanded'] }); 

  try {
    response = await sendMessage({ action: 'enableSchedule' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    toastMessage(`Błąd! ${error instanceof Error ? error.message : error}`);
  }

  const topMessageIconMutationObserver = new MutationObserver(mutations => {
    mutations.forEach(async (mutation) => {
      if (mutation.removedNodes.length) {
        const messageIconBadge = drawerMessageIcon.querySelector('#messageIconBadge');
        if (messageIconBadge) messageIconBadge.remove();
      } else {
        let messageIconBadge;
        messageIconBadge = drawerMessageIcon.querySelector('#messageIconBadge');
        if (!messageIconBadge) {
          messageIconBadge = document.createElement('div');
          messageIconBadge.id = 'messageIconBadge';
          messageIconBadge.className = (mutation.type === 'characterData' ? mutation.target.parentNode.className : mutation.target.children[1].className);
          messageIconBadge.classList.remove('mp7g_f6');
          messageIconBadge.textContent = (mutation.type === 'characterData' ? mutation.target.textContent : mutation.target.children[1].textContent);
          drawerMessageIcon.firstChild.firstChild.after(messageIconBadge);
        } else {
          messageIconBadge.textContent = (mutation.type === 'characterData' ? mutation.target.textContent : mutation.target.children[1].textContent);
        }
      }
      toastMessage('Sprawdzanie wiadomości');
      try {
        response = await sendMessage({ action: 'checkForUnreadMessages', silent: false });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
        toastMessage(`Błąd! ${error instanceof Error ? error.message : error}`);
      }
    });
  });

  if (topMessageIcon.nextElementSibling !== null) {
    let messageIconBadge = document.createElement('div');
    messageIconBadge.id = 'messageIconBadge';
    messageIconBadge.className = topMessageIcon.nextElementSibling.className;
    messageIconBadge.classList.remove('mp7g_f6');
    messageIconBadge.textContent = topMessageIcon.nextElementSibling.textContent;
    drawerMessageIcon.firstChild.firstChild.after(messageIconBadge); 
  }

  const topDiscussionIconMutationObserver = new MutationObserver(mutations => {
    mutations.forEach(async (mutation) => {
      if (mutation.removedNodes.length) {
        const discussionIconBadge = drawer.querySelector('#discussionIconBadge');
        if (discussionIconBadge) discussionIconBadge.remove();
        delete drawerOrdersAndReturnsIcon.dataset.unread;
      } else {
        let discussionIconBadge;
        discussionIconBadge = drawer.querySelector('#discussionIconBadge');
        if (!discussionIconBadge) {
          discussionIconBadge = document.createElement('div');
          discussionIconBadge.id = 'discussionIconBadge';
          discussionIconBadge.className = (mutation.type === 'characterData' ? mutation.target.parentNode.className : mutation.target.children[1].className);
          discussionIconBadge.classList.remove('mp7g_f6');
          discussionIconBadge.textContent = (mutation.type === 'characterData' ? mutation.target.textContent : mutation.target.children[1].textContent);

          const discussionMenu = drawer.querySelector('a[href="/discussions-with-buyers"]');
          if (drawer.offsetWidth > 100) {
            if (discussionMenu) {
              discussionIconBadge.classList.add('badgeMoved');
              discussionMenu.before(discussionIconBadge);
            } else drawerOrdersAndReturnsIcon.firstChild.firstChild.after(discussionIconBadge);
          } else {
            drawerOrdersAndReturnsIcon.firstChild.firstChild.after(discussionIconBadge);
          }
        } else {
          discussionIconBadge.textContent = (mutation.type === 'characterData' ? mutation.target.textContent : mutation.target.children[1].textContent);
        }
        drawerOrdersAndReturnsIcon.dataset.unread = discussionIconBadge.textContent;
      }
      toastMessage('Sprawdzanie wiadomości');
      try {
        response = await sendMessage({ action: 'checkForUnreadMessages', silent: false });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
        toastMessage(`Błąd! ${error instanceof Error ? error.message : error}`);
      }
    });
  });

  if (topDiscussionIcon.nextElementSibling !== null) {
    let discussionIconBadge = document.createElement('div');
    discussionIconBadge.id = 'discussionIconBadge';
    discussionIconBadge.className = topDiscussionIcon.nextElementSibling.className;
    discussionIconBadge.classList.remove('mp7g_f6');
    discussionIconBadge.textContent = topDiscussionIcon.nextElementSibling.textContent;
    drawerOrdersAndReturnsIcon.dataset.unread = discussionIconBadge.textContent;
    const discussionMenu = drawer.querySelector('a[href="/discussions-with-buyers"]');
    if (drawer.offsetWidth > 100) {
      if (discussionMenu) {
        discussionIconBadge.classList.add('badgeMoved'); 
        discussionMenu.before(discussionIconBadge);
      } else drawerOrdersAndReturnsIcon.firstChild.firstChild.after(discussionIconBadge);
    } else {
      drawerOrdersAndReturnsIcon.firstChild.firstChild.after(discussionIconBadge);
    }
  }

  topMessageIconMutationObserver.observe(topMessageIcon.parentElement, { childList: true, subtree: true, characterData: true });
  topDiscussionIconMutationObserver.observe(topDiscussionIcon.parentElement, { childList: true, subtree: true, characterData: true });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  asyncOnMessageCallback(request, sender).then(resolved => { sendResponse({ success: true, result: resolved }) }).catch(rejected => { sendResponse({ success: false, result: rejected }) });
	return true;
});

async function asyncOnMessageCallback(request, sender) {
	const action = request.action;
  switch (action) {
    case 'updateIcon': {
      if (action === 'updateIcon') {
        let messageIcons, drawerMessageIcon, topDiscussionIcon, topMessageIcon, drawerOrdersAndReturnsIcon;
        try {
          [ messageIcons, topDiscussionIcon, drawerOrdersAndReturnsIcon ] = await waitForMenu();
        } catch (error) {
          toastMessage(`Błąd! ${error instanceof Error ? error.message : error}`);
          return Promise.reject(false);
        }

        topMessageIcon = messageIcons[0];
        drawerMessageIcon = messageIcons[1];

        if (request.data.message.status === 'unread') {
          drawerMessageIcon.parentElement.classList.add('unread');
          if (!request.data.message.silent) toastMessage('Masz nieprzeczytaną wiadomość.');
        } else {
          drawerMessageIcon.parentElement.classList.remove('unread');
        }
        
        const drawer = document.querySelector('header[data-testid="drawer-menu"]');
        const drawerShow = (parseFloat(getComputedStyle(drawer).width) > 100);
        const discussionMenu = drawer.querySelector('a[href="/discussions-with-buyers"]');
        
        if (request.data.dispute.status === 'new' || request.data.dispute.status === 'unread') {
          if (!drawerOrdersAndReturnsIcon.dataset.unread) drawerOrdersAndReturnsIcon.dataset.unread = true;
          if (drawerShow && drawerOrdersAndReturnsIcon.getAttribute('aria-expanded') === 'true') {
            discussionMenu.classList.add('unread');
          } else {
            drawerOrdersAndReturnsIcon.classList.add('unread');
            drawerOrdersAndReturnsIcon.querySelector('p').style.setProperty('background', 'none', 'important');
          }
          if (request.data.dispute.status === 'new') toastMessage('Masz nową wiadomość w dyskusji.');
        } else {
          drawerOrdersAndReturnsIcon.classList.remove('unread');
          delete drawerOrdersAndReturnsIcon.dataset.unread;
          discussionMenu?.classList.remove('unread');
        }
      }
      return Promise.resolve(true);
    }
    case 'toast': {
      toastMessage(request.message);
      return Promise.resolve(true);
    }
  }
}

async function waitForMenu(retry = 10) {
  const topBar = document.querySelector('div[data-box-name="allegro.salescenter.bar"]');
  if (!topBar) {
    if (--retry) {
      const delay = t => new Promise(resolve => setTimeout(resolve, t));
      await delay(5000);
      return await waitForMenu(retry);
    } else {
      return Promise.reject('Nie znaleziono górnego menu. Rozszerzenie nie będzie działać.');  
    }
  }

  let messageIcons = document.querySelectorAll('a[href="/message-center/messages"]');
  let topDiscussionIcon = topBar.querySelector('a[href="/discussions-with-buyers"]');
  let drawerOrdersAndReturnsIcon = document.querySelector('button[aria-controls="ordersAndReturns"]');

  if (!messageIcons || !topDiscussionIcon || !drawerOrdersAndReturnsIcon) {
    if (--retry) {
      const delay = t => new Promise(resolve => setTimeout(resolve, t));
      await delay(5000);
      return await waitForMenu(retry);
    } else {
      return Promise.reject('Nie znaleziono ikon. Rozszerzenie nie będzie działać.');  
    }
  } else {
    return Promise.resolve([messageIcons, topDiscussionIcon, drawerOrdersAndReturnsIcon]);
  }
}
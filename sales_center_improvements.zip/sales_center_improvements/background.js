const JSON_DECODE_ERROR = 'Podczas dekodowania odpowiedzi serwera wystąpił błąd.';
const FETCH_ERROR_MESSAGE = 'Podczas wysyłania żądania wystąpił błąd.';
const HTTP_RESPONSE_CODE = 'Kod odpowiedzi HTTP:';
const UNABLE_TO_REFRESH_TOKENS = 'Nie udało się odświeżyć tokenów dostępowych.';
const REFRESHED_TOKENS_SAVE_ERROR = 'Odświeżono tokeny dostępowe jednak ich zapis się nie udał. Zaloguj ponownie aplikację na stronie opcji rozszerzenia celem uzyskania nowych tokenów.';
const ERROR_403 = 'Upewnij się że logujesz się właściwymi danymi oraz że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.';

//const environment = '.allegrosandbox.pl';
const environment = '';

(function main() {
  console.log('Załadowano rozszerzenie Sales Center Improvements');
  chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });

  (async () => {
		for (const contentScript of chrome.runtime.getManifest().content_scripts) {
			for (const tab of await chrome.tabs.query({ url: contentScript.matches })) {
				try {
					chrome.scripting.insertCSS({
						target: { tabId: tab.id },
						files: contentScript.css
					});
					chrome.scripting.executeScript({
						target: { tabId: tab.id },
						files: contentScript.js
					});
					console.log('odświeżono skrypty na otwartych stronach.');					
				} catch (error) {
					showMessageFromBackground('Błąd! Nie udało się odświeżyć skryptów.');
				}
			}
		}

    let schedule;
    try {
      schedule = await checkAlarm();
      if (schedule) {
        await setIcon('green'); 
        console.log('włączono automatyczne sprawdzanie wiadomości');
      } else {
        await setIcon('red');
        console.log('wyłączono automatyczne sprawdzanie wiadomości');
      }
    } catch (error) {
      showMessageFromBackground('Błąd! Nie udało się pobrać stanu automatycznego sprawdzania wiadomości. Ikona rozszerzenia może nie pokazywać właściwego trybu działania. Odśwież dowolną stronę Sales Center aby wymusić włączenie automatycznego działania.');
    }
	})();
})();	

async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(result); 
    });
  });
}

async function sendMessage(tab, data) {
	return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tab, data, (response) => {
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response); 
	  });
  });
}

function optionsPageMessage(textMessage) {
	chrome.storage.session.set({ message: textMessage }).then(() => {
		chrome.runtime.openOptionsPage();
	});
}

/*
chrome.storage.local.get(['']).then((result) => {
  if (chrome.runtime.lastError) {
    console.log('Błąd! Nie udało się odczytać danych z pamięci.');
    return;
  }
  console.log('Odczytano dane z pamięci:');
  console.log(result);
});
*/
/*
chrome.storage.local.remove('').then((result) => {
  if (chrome.runtime.lastError) {
    console.log('Błąd! Nie udało się usunąć danych z pamięci.');
    return;
  }
  console.log('Usunięto dane z pamięci.');
});
*/
/*
chrome.storage.local.set({allegroAccessToken : '' }).then(() => {
  if (chrome.runtime.lastError) {
    console.log('Błąd! Nie udało się zapisać danych w pamięci.');
    return;
  }
  console.log('Zapisano dane w pamięci.');
});
*/

chrome.runtime.onInstalled.addListener(details => {
	if (details.reason === 'install') {
		async function setDefaultValues() {
			try {
				await saveDataToLocalStorage({
					allegroAPIClientId: '',
					allegroAPIClientSecret: '',
					allegroAccessToken: '',
					allegroRefreshToken: '',
          systemNotifications: false
				});
				return Promise.resolve('Uzupełnij parametry wymagane do działania aplikacji.');
			} catch (error) {
				return Promise.reject(`Podczas inicjalizacji domyślnych parametrów wystąpił błąd. ${error.message}`);
			}
		}
		setDefaultValues().then(message => {
			optionsPageMessage(message);
		}).catch(error => {
			optionsPageMessage(`Błąd! ${error}`);
		})
  }
});

chrome.runtime.onSuspend.addListener(() => {
  chrome.alarms.clear('checkMessagesAndDisputes');
});

async function checkAlarm() {
  let schedule;
  try {
    schedule = await new Promise((resolve, reject) => {
      chrome.alarms.get('checkMessagesAndDisputes', (alarm) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          if (alarm) resolve(true);
          else resolve(false);
        }
      });
    });
  } catch (error) {
    return Promise.reject(error.message);
  }
  return Promise.resolve(schedule);
}

async function showMessageFromBackground(message) {
  let tab;
  try {
    tab = await getCurrentTab();
  } catch (error) {
    console.log(error);
  }

  if (tab !== undefined) {
    try {
      sendMessage(tab.id, { action: 'toast', message: message });
    } catch (error) {
      console.log(error.message);
      const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
      if (notificationsAllowed) {
        chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Błąd rozszerzenia Usprawnienia Sales Center', message: message });
      } else {
        optionsPageMessage(message);
      }
    }
  } else {
    if (message.startsWith('Błąd!')) {
      const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
      if (notificationsAllowed) {
        chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Błąd rozszerzenia Usprawnienia Sales Center', message: message });
      } else {
        optionsPageMessage(message);
      }
    }
  }
  return Promise.resolve(true);
}

async function getCurrentTab() {
  const queryOptions = { active: true, currentWindow: true, status: 'complete', url: `https://salescenter.allegro.com${environment}/*` };
  try {
    let [tab] = await chrome.tabs.query(queryOptions);
    return Promise.resolve(tab);
  } catch (error) {
    return Promise.reject('Nie udało się pobrać aktywnej karty.');
  }
}

async function disableSchedule() {
  chrome.alarms.clear('checkMessagesAndDisputes');
  showMessageFromBackground('Automatyczne sprawdzanie wiadomości i dyskusji zostało wyłączone');
  try {
    await setIcon('red');
  } catch (error) {
    return Promise.reject(error instanceof Error ? error.message : error);
  }
  console.log('wyłączono automatyczne sprawdzanie wiadomości');
  return Promise.resolve(true);
}

async function resetSchedule() {
  let alarm;
  try {
    alarm = await checkAlarm();
    if (alarm) {
      await chrome.alarms.create('checkMessagesAndDisputes', {
        delayInMinutes: 1,
        periodInMinutes: 1
      });
    }
  } catch (error) {
    return Promise.reject('Nie udało się wstrzymać następnego zaplanowanego sprawdzania wiadomości.');
  }
  return Promise.resolve(true);
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'checkMessagesAndDisputes') {
    try {
      await checkMessages();
    } catch (error) {
      console.log(error instanceof Error ? error.message : error);
      showMessageFromBackground(`Błąd! ${error instanceof Error ? error.message : error}`);
    }
  }
});

async function refreshToken() {
  let readedValue;
  let fetchResponse;
  let fetchData;
  try {
    readedValue = await readDataFromLocalStorage(['allegroRefreshToken', 'allegroAPIClientId', 'allegroAPIClientSecret']);
  } catch (error) {
    return Promise.reject(`Podczas odczytu danych potrzebnych do odświeżenia tokena dostępowego wystąpił błąd. ${error.message}`);
  }		
  if (readedValue['allegroRefreshToken'] === undefined || readedValue['allegroRefreshToken'] === '' || readedValue['allegroAPIClientId'] === undefined || readedValue['allegroAPIClientId'] === '' || readedValue['allegroAPIClientSecret'] === undefined || readedValue['allegroAPIClientSecret'] === '') return Promise.reject('Brak danych potrzebnych do odświeżenia tokena dostępowego. Zaloguj ponownie aplikację do Allegro na stronie opcji rozszerzenia.');

  const allegroAPIClientId = readedValue['allegroAPIClientId'];
  const allegroAPIClientSecret = readedValue['allegroAPIClientSecret'];
  const allegroRefreshToken = readedValue['allegroRefreshToken'];
  const redirectUrl = chrome.identity.getRedirectURL('salescenter');
  try {
    fetchResponse = await fetch(`https://allegro.pl${environment}/auth/oauth/token?grant_type=refresh_token&refresh_token=${allegroRefreshToken}&redirect_uri=${redirectUrl}`, {
      'method': 'POST',
      'headers': {
        'Authorization': `Basic ${btoa(allegroAPIClientId + ':' + allegroAPIClientSecret)}`,
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });
  } catch (error) {
    return Promise.reject('Nie udało się odświeżyć tokena dostępowego (problem podczas wysyłania żądania). Odczekaj chwilę i spróbuj ponownie lub zaloguj aplikację do Allegro na stronie opcji rozszerzenia.');
  }

  if (fetchResponse.status === 200) {
    try {
      fetchData = await fetchResponse.json();
    } catch (error) {
      return Promise.reject(`${JSON_DECODE_ERROR} ${error.message}`);
    }

    if (fetchData.access_token === undefined || fetchData.refresh_token === undefined) return Promise.reject('Serwer Allegro nie zwrócił nowych tokenów dostępowych. Odczekaj chwilę i spróbuj ponownie.');
    try {
      await saveDataToLocalStorage({ allegroAccessToken: fetchData.access_token, allegroRefreshToken: fetchData.refresh_token });
    } catch (error) {
      return Promise.reject(`${REFRESHED_TOKENS_SAVE_ERROR} ${error.message}`);
    }
  } else if (fetchResponse.status === 403) {
    return Promise.reject(ERROR_403);
  } else {
    return Promise.reject('Nie udało się odświeżyć tokena dostępowego (serwer Allegro nie zwraca prawidłowej odpowiedzi). Odczekaj chwilę i spróbuj ponownie lub zaloguj aplikację do Allegro na stronie opcji rozszerzenia.');	
  }
}

async function checkMessages(silent = false) {
  console.log('Wyszukiwanie nieprzeczytanych wiadomości...');
  let fetchResponse;
  let fetchData;
  let accessToken;
  let messagesResult, disputesResult;
  let unreadNessageFound = false, unreadDisputeFound = false, unreadDisputeFoundSilent = false;
  let readedValue;
  try {
    readedValue = await readDataFromLocalStorage(['allegroAccessToken']);
  } catch (error) {
    return Promise.reject(`Podczas odczytu zapisanego tokena dostępowego wystąpił błąd. ${error.message}`);
  }
  if (readedValue['allegroAccessToken'] !== undefined && readedValue['allegroAccessToken'] !== '') accessToken = readedValue['allegroAccessToken'];
  else {
    return Promise.reject('Wymagane jest zalogowanie rozszerzenia do serwisu Allegro, uzupełnij dane dostępowe na stronie opcji rozszerzenia, kliknij zapisz i następnie zaloguj.');
  }

  async function getThreads(offset, count) {
    try {
      fetchResponse = await fetch(`https://api.allegro.pl${environment}/messaging/threads?offset=${offset}`, {
        'method': 'GET',
        'headers': {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/vnd.allegro.public.v1+json',
          'Accept': 'application/vnd.allegro.public.v1+json'
        }
      });
    } catch (error) {
      return Promise.reject(`${FETCH_ERROR_MESSAGE} ${error.message}`);
    }

    if (fetchResponse.status === 200) {
      try {
        fetchData = await fetchResponse.json();
      } catch (error) {
        return Promise.reject(`${JSON_DECODE_ERROR} ${error.message}`);
      }
      for (let thread of fetchData.threads) {
        if (thread.read === false) {
          unreadNessageFound = true;
          break;
        }
      }
      if (!unreadNessageFound) {
        if (fetchData.threads.length === 20) {
          offset += 20;
          return await getThreads(offset, 5);
        } else {
          return Promise.resolve('done');
        }
      } else {
        return Promise.resolve('unread');
      }
    } else if (fetchResponse.status === 401) {
      if (--count) {
        await resetSchedule().catch(e => { console.log(e) });
        console.log(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
        const delay = t => new Promise(resolve => setTimeout(resolve, t));
        await delay(5000);

        try {
          await refreshToken(); 
        } catch (error) {
          if (error.message === ERROR_403) {
            disableSchedule().catch(e => { console.log(e) }); 
            return Promise.reject(ERROR_403);
          }
        }

        try {
          readedValue = await readDataFromLocalStorage(['allegroAccessToken']);
        } catch (error) {
          return Promise.reject(`Podczas odczytu zapisanego tokena dostępowego wystąpił błąd. ${error.message}`);
        }
        if (readedValue['allegroAccessToken'] !== undefined && readedValue['allegroAccessToken'] !== '') accessToken = readedValue['allegroAccessToken'];
        else {
          return Promise.reject('Wymagane jest zalogowanie rozszerzenia do serwisu Allegro, uzupełnij dane dostępowe na stronie opcji rozszerzenia, kliknij zapisz i następnie zaloguj.');
        }

        return await getThreads(offset, count);
      } else {
        disableSchedule().catch(e => { console.log(e) });
        return Promise.reject('Nie udało się pobrać listy wiadomości. Nie udało się zalogować użytkownika.');
      }
    } else if (fetchResponse.status === 403) {
      disableSchedule().catch(e => { console.log(e) });
      return Promise.reject(ERROR_403);
    } else {
      if (--count) {
        await resetSchedule().catch(e => { console.log(e) });
        console.log(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
        const delay = t => new Promise(resolve => setTimeout(resolve, t));
        await delay(5000);
        return await getThreads(offset, count);
      } else {
        return Promise.reject(`Nie udało się pobrać listy wiadomości. Kod HTTP: ${fetchResponse.status}`);
      }
    }
  }

  async function getDisputes(offset, count) {
    let disputeStats;
    try {
      fetchResponse = await fetch(`https://api.allegro.pl${environment}/sale/disputes?status=ONGOING&limit=20&offset=${offset}`, {
        'method': 'GET',
        'headers': {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/vnd.allegro.public.v1+json',
          'Accept': 'application/vnd.allegro.public.v1+json'
        }
      });
    } catch (error) {
      return Promise.reject(`${FETCH_ERROR_MESSAGE} ${error.message}`);
    }

    if (fetchResponse.status === 200) {
      try {
        fetchData = await fetchResponse.json();
      } catch (error) {
        return Promise.reject(`${JSON_DECODE_ERROR} ${error.message}`);
      }
      for (let dispute of fetchData.disputes) {
        if (['NEW', 'BUYER_REPLIED', 'ALLEGRO_ADVISOR_REPLIED'].includes(dispute.messagesStatus)) {
          try {
            disputeStats = await readDataFromLocalStorage([`dispute_${dispute.id}`]);
          } catch (error) {
            return Promise.reject('Nie udało się odczytać liczby wiadomości w dyskusji.');
          }

          if (disputeStats[`dispute_${dispute.id}`] === undefined  || (dispute.messagesCount > disputeStats[`dispute_${dispute.id}`].messagesCount)) {
            unreadDisputeFound = true;
            if (disputeStats[`dispute_${dispute.id}`] === undefined) {
              disputeStats[`dispute_${dispute.id}`] = {
                unread: true
              }
            } else disputeStats[`dispute_${dispute.id}`].unread = true;

            disputeStats[`dispute_${dispute.id}`].messagesCount = dispute.messagesCount;

            try {
              await saveDataToLocalStorage({ [`dispute_${dispute.id}`]: disputeStats[`dispute_${dispute.id}`] });
            } catch (error) {
              return Promise.reject('Nie udało się zapisać liczby wiadomości w dyskusji.');
            }
          } else if (disputeStats[`dispute_${dispute.id}`].unread) {
            unreadDisputeFoundSilent = true;
          }
        }
      }
      if (!(unreadDisputeFound || unreadDisputeFoundSilent)) {
        if (fetchData.disputes.length === 20) {
          offset += 20;
          return await getDisputes(offset, 5);
        } else {
          return Promise.resolve('done');
        }
      } else if (unreadDisputeFound) {
        return Promise.resolve('new');
      } else if (unreadDisputeFoundSilent) {
        return Promise.resolve('unread');
      }
    } else if (fetchResponse.status === 401) {
      if (--count) {
        await resetSchedule().catch(e => { console.log(e) });
        console.log(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
        const delay = t => new Promise(resolve => setTimeout(resolve, t));
        await delay(5000);

        try {
          await refreshToken(); 
        } catch (error) {
          if (error.message === ERROR_403) {
            disableSchedule().catch(e => { console.log(e) });
            return Promise.reject(ERROR_403);
          }
        }

        try {
          readedValue = await readDataFromLocalStorage(['allegroAccessToken']);
        } catch (error) {
          return Promise.reject(`Podczas odczytu zapisanego tokena dostępowego wystąpił błąd. ${error.message}`);
        }
        if (readedValue['allegroAccessToken'] !== undefined && readedValue['allegroAccessToken'] !== '') accessToken = readedValue['allegroAccessToken'];
        else {
          return Promise.reject('Wymagane jest zalogowanie rozszerzenia do serwisu Allegro, uzupełnij dane dostępowe na stronie opcji rozszerzenia, kliknij zapisz i następnie zaloguj.');
        }

        return await getDisputes(offset, count);
      } else {
        disableSchedule().catch(e => { console.log(e) });
        return Promise.reject('Nie udało się pobrać listy dyskusji. Nie udało się zalogować użytkownika.');
      }
    } else if (fetchResponse.status === 403) {
      disableSchedule().catch(e => { console.log(e) });
      return Promise.reject(ERROR_403);
    } else {
      if (--count) {
        await resetSchedule().catch(e => { console.log(e) });
        console.log(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
        const delay = t => new Promise(resolve => setTimeout(resolve, t));
        await delay(5000);
        return await getDisputes(offset, count);
      } else {
        return Promise.reject(`Nie udało się pobrać listy dyskusji. Kod HTTP: ${fetchResponse.status}`);
      }
    }
  }

  const statusTranslated = {
    new : 'nowa wiadomość',
    unread: 'nieprzeczytana',
    done : 'gotowe'
  }
  
  try {
    messagesResult = await getThreads(0, 5);
    disputesResult = await getDisputes(0, 5);
    console.log(`wiadomości: ${statusTranslated[messagesResult]}`);
    console.log(`dyskusje: ${statusTranslated[disputesResult]}`);
    let messageShown = false;
    for (const tab of await chrome.tabs.query({ status: 'complete', url: `https://salescenter.allegro.com${environment}/*` })) {
      messageShown = true;
      sendMessage(tab.id, { action: 'updateIcon', data: { 
        message: {
          status: messagesResult,
          silent: silent
        },
        dispute: {
          status: disputesResult 
        }
      }});
    }
    if (!messageShown && (messagesResult !== 'done' || disputesResult !== 'done')) {
      try {
        readedValue = await readDataFromLocalStorage(['systemNotifications']);
      } catch (error) {
        return Promise.reject(`Podczas odczytu ustawień powiadomień wystąpił błąd. ${error.message}`);
      }
      if (readedValue['systemNotifications']) {
        const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
        if (notificationsAllowed) {
          chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
            if (buttonIndex === 0) {
              chrome.tabs.create({ url: `https://salescenter.allegro.com${environment}/my-sales` });
            }
          });
          chrome.notifications.create('salescenter-extension-new-message', { type: 'basic', iconUrl: 'info_48x48.png', requireInteraction: true, title: 'Usprawnienia Sales Center', message: 'Masz nową wiadomość w Sales Center', buttons: [{ title: 'Otwórz stronę Sales Center' }] });
        } else {
          await saveDataToLocalStorage({ systemNotifications: false });
          optionsPageMessage('Błąd! Masz wyłączone pozwolenie na pokazywanie powiadomień systemowych. Zezwól na powiadomienia w "Ustawieniach witryn" dostępnych po kliknięciu "Szczegóły" na karcie "Rozszerzenia" i włącz ponownie opcję powiadomień systemowych w opcjach rozszerzenia.');
        }    
      } else if (messagesResult === 'done' && disputesResult === 'done') {
        chrome.notifications.clear('salescenter-extension-new-message');
      }
    }
  } catch (error) {
    return Promise.reject(error instanceof Error ? error.message : error);
  }
}

(async function checkUpdate() {
	let fetchResponse;
	try {
		fetchResponse = await fetch('https:/raw.githubusercontent.com/tomsyty/Sales-center-improvements/main/current-version');
	} catch (error) {
		const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
		if (notificationsAllowed) {
			chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
				if (buttonIndex === 0) {
					chrome.tabs.create({ url: 'https://github.com/tomsyty/Sales-center-improvements' });
				}
			});
			chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: ` Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". Sprawdź wersję ręcznie na stronie rozszerzenia.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
		} else {
			optionsPageMessage(`Błąd! Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". ${error.message}`);
		}
		return;
	}

	if (fetchResponse.status === 200) {
		const currentVersion = await fetchResponse.text();
		if (currentVersion.trim() !== chrome.runtime.getManifest().version) {
			const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
			if (notificationsAllowed) {
				chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
					if (buttonIndex === 0) {
						chrome.tabs.create({ url: 'https://github.com/tomsyty/Sales-center-improvements' });
					}
				});
				chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: `Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
			} else {
				optionsPageMessage(`Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`);
			}
		}
	} else {
		console.log('brak pliku z informacją o aktualizacji');
	}
})();

async function setIcon(color) {
  return new Promise((resolve, reject) => {
    chrome.action.setIcon({
      path: {
        '16': `icon_16x16_${color}.png`,
        '48': `icon_48x48_${color}.png`,
        '128': `icon_128x128_${color}.png`
      }
    }, () => {
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(true); 
    });
  });
}

async function handleBackgroundFetch(request) {
  const response = await fetch(request.url, {
    method: request.options.method || 'GET',
    headers: request.options.headers || {},
    body: request.options.body || null
  });

  const responseBody = await response.text();
  return {
    status: response.status,
    statusText: response.statusText,
    headers: Array.from(response.headers.entries()),
    body: responseBody
  };
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	asyncOnMessageCallback(request, sender).then(resolved => { sendResponse({ success: true, result: resolved }) }).catch(rejected => { sendResponse({ success: false, result: (rejected instanceof Error ? rejected.message : rejected) }) });
	return true;
});

async function asyncOnMessageCallback(request, sender) {
	const action = request.action;
	switch (action) {
    case 'backgroundFetch': {
			return await handleBackgroundFetch(request);
		}

    case 'checkForUnreadMessages': {
      try {
        await resetSchedule();
        await checkMessages(request.silent ?? false);
      } catch (error) {
        return Promise.reject(error instanceof Error ? error.message : error);
      }
      return Promise.resolve(true);
    }

		case 'refreshAllegroAccessToken': {
			let readedValue;
			try {
				readedValue = await readDataFromLocalStorage(['allegroRefreshToken', 'allegroAPIClientId', 'allegroAPIClientSecret']);
			} catch (error) {
				return Promise.reject(`Podczas odczytu danych potrzebnych do odświeżenia tokena dostępowego wystąpił błąd. ${error.message}`);
			}		
			if (readedValue['allegroRefreshToken'] === undefined || readedValue['allegroRefreshToken'] === '' || readedValue['allegroAPIClientId'] === undefined || readedValue['allegroAPIClientId'] === '' || readedValue['allegroAPIClientSecret'] === undefined || readedValue['allegroAPIClientSecret'] === '') return Promise.reject('Brak danych potrzebnych do odświeżenia tokena dostępowego. Zaloguj ponownie aplikację do Allegro na stronie opcji rozszerzenia.');
			
			const allegroAPIClientId = readedValue['allegroAPIClientId'];
			const allegroAPIClientSecret = readedValue['allegroAPIClientSecret'];
			const allegroRefreshToken = readedValue['allegroRefreshToken'];
			const redirectUrl = chrome.identity.getRedirectURL('salescenter');

      async function login(count = 3) {
        let fetchResponse;
        let fetchData;
        try {
          fetchResponse = await fetch(`https://allegro.pl${environment}/auth/oauth/token?grant_type=refresh_token&refresh_token=${allegroRefreshToken}&redirect_uri=${redirectUrl}`, {
            'method': 'POST',
            'headers': {
              'Authorization': `Basic ${btoa(allegroAPIClientId + ':' + allegroAPIClientSecret)}`,
              'Content-Type': 'application/x-www-form-urlencoded'
            }
          });
        } catch (error) {
          if (--count) {
            const delay = t => new Promise(resolve => setTimeout(resolve, t));
            await delay(5000);
            return await login(count);
          } else {
            return Promise.reject('Nie udało się odświeżyć tokena dostępowego (problem podczas wysyłania żądania). Odczekaj chwilę i spróbuj ponownie lub zaloguj aplikację do Allegro na stronie opcji rozszerzenia.');
          }
        }

        if (fetchResponse.status === 200) {
          try {
            fetchData = await fetchResponse.json();
          } catch (error) {
            return Promise.reject(`${JSON_DECODE_ERROR} ${error.message}.`);
          }

          if (fetchData.access_token === undefined || fetchData.refresh_token === undefined) return Promise.reject('Serwer Allegro nie zwrócił nowych tokenów dostępowych. Odczekaj chwilę i spróbuj ponownie.');

          try {
            await saveDataToLocalStorage({ allegroAccessToken: fetchData.access_token, allegroRefreshToken: fetchData.refresh_token });
          } catch (error) {
            return Promise.reject(`${REFRESHED_TOKENS_SAVE_ERROR} ${error.message}`);
          }
            
          return Promise.resolve(fetchData.access_token);
        } else {
          if (--count) {
            const delay = t => new Promise(resolve => setTimeout(resolve, t));
            await delay(5000)
            return await login(count);
          } else {
            return Promise.reject('Nie udało się odświeżyć tokena dostępowego (serwer Allegro nie zwraca prawidłowej odpowiedzi). Odczekaj chwilę i spróbuj ponownie lub zaloguj aplikację do Allegro na stronie opcji rozszerzenia.');
          }	
        }
      }
      try {
        const result = await login();
        return Promise.resolve(result);
      } catch (error) {
        return Promise.reject(error instanceof Error ? error.message : error);
      }				
		}

    case 'allegroAPISave': {
			if (request.clientId === undefined || request.clientSecret === undefined) return Promise.reject('Nie podano wartości parametrów Client ID i Cilent Secret.');
			let patternClientId = /[0-9a-f]{32}/;
			let patternClientSecret = /[0-9a-zA-Z]{64}/;
			if ((!patternClientId.test(request.clientId)) || (!patternClientSecret.test(request.clientSecret))) return Promise.reject('Podane wartości parametrów są niepoprawne.');

			try {
				await saveDataToLocalStorage({ allegroAPIClientId: request.clientId, allegroAPIClientSecret: request.clientSecret, allegroAccessToken: '', allegroRefreshToken: '' });
        chrome.alarms.clear('checkMessagesAndDisputes');
        await setIcon('red');
			} catch (error) {
				return Promise.reject(`Podczas zapisu parametrów wystąpił błąd. ${error instanceof Error ? error.message : error}`);
			}
			return Promise.resolve(true);		
		}

    case 'enableSchedule': {
      const schedule = await checkAlarm();
      if (!schedule) {
        try {
          await checkMessages();        
          await chrome.alarms.create('checkMessagesAndDisputes', {
            delayInMinutes: 1,
            periodInMinutes: 1
          });
          await setIcon('green');
        } catch (error) {
          console.log(error instanceof Error ? error.message : error);
          showMessageFromBackground(`Błąd! ${error instanceof Error ? error.message : error}`);
          return Promise.reject(`Nie udało się włączyć automatycznego sprawdzania wiadomości. Rozszerzenie nie będzie działać.`);
        }
        console.log('włączono automatyczne sprawdzanie wiadomości');
        return Promise.resolve(true);
      } else {
        return Promise.resolve(true);
      }   
    }

    case 'checkSchedule': {
      let schedule;
      try {
        schedule = await checkAlarm();
      } catch (error) {
        return Promise.reject(error instanceof Error ? error.message : error);
      }
      return Promise.resolve(schedule);
    }
  }
}
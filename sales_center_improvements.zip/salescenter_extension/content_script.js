async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}

async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

async function saveDataToSessionStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.session.set(data, () => {
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(true); 
    });
  });
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: 'backgroundFetch',
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt salesCenterImprovements');	
  let toast;
  let disputeId;
  let readedValue;
  let sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  let environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  const disputeHrefRegex = new RegExp(`https:\/\/salescenter\.allegro\.com${sandbox === 'Sandbox' ? '\.allegrosandbox\.pl' : ''}\/discussions-with-buyers\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}`);
  const disputeIdRegex = new RegExp(`(?<=https:\/\/salescenter\.allegro\.com${sandbox === 'Sandbox' ? '\.allegrosandbox\.pl' : ''}\/discussions-with-buyers\/)[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}`);
  toast = document.getElementById('aeToast');
  if (toast === null) {
    toast = document.createElement('div');
    toast.id = 'aeToast';
    toast.classList.add('aeToastHidden');
    document.body.appendChild(toast);
  }

  if (window.location.href.startsWith(`https://salescenter.allegro.com${environment}/message-center/messages/`)) {
    const delay = t => new Promise(resolve => setTimeout(resolve, t));
    await delay(5000);
    try {
      await sendMessage( { action: 'checkForUnreadMessages', silent: true });
    } catch (error) {
      toastMessage(`Błąd! ${error.message}`);
    }
  } else if (window.location.href.search(disputeHrefRegex) !== -1) {
    disputeId = disputeIdRegex.exec(window.location.href);
    try {
      readedValue = await readDataFromLocalStorage([`dispute_${disputeId}`]);
    } catch (error) {
      toastMessage(`Błąd! Nie udało się sprawdzić statystyk dotyczących dyskusji ${disputeId}.`);
    }
    if (readedValue[`dispute_${disputeId}`] !== undefined) {
      if (readedValue[`dispute_${disputeId}`].unread === true) {
        readedValue[`dispute_${disputeId}`].unread = false;
        try {
          await saveDataToLocalStorage({ [`dispute_${disputeId}`]: readedValue[`dispute_${disputeId}`] });
          toastMessage('Dyskusja oznaczona jako przeczytana.');
        } catch (error) {
          toastMessage(`Błąd! Nie udało się oznaczyć dyskusji ${disputeId} jako przeczytanej.`);
        }
      }
    }
  } else if (window.location.href.startsWith(`https://salescenter.allegro.com${environment}/my-sales`)) {
    toastMessage('Sprawdzanie wiadomości');
    try {
      await sendMessage( { action: 'checkForUnreadMessages', silent: false });
    } catch (error) {
      toastMessage(`Błąd! ${error.message}`);
    }
  } 
  
  let messageIcon, ordersAndReturnsIcon;
  try {
    [ messageIcon, ordersAndReturnsIcon ] = await waitForMenu();
  } catch (error) {
    toastMessage(`Błąd! ${error.message}`);
    return Promise.reject(false);
  }

  const drawer = document.querySelector('header[data-testid="drawer-menu"]');
  drawer.addEventListener('transitionend', (e) => {
    if (e.propertyName === 'width') {
      const discussionMenu = drawer.querySelector('a[href="/discussions-with-buyers"]');
      if (drawer.offsetWidth <= 100) {
        if (discussionMenu?.classList.contains('unread')) {
          ordersAndReturnsIcon.classList.add('unread');
          discussionMenu.classList.remove('unread');
        } 
      } else {
        if (ordersAndReturnsIcon.classList.contains('unread') && ordersAndReturnsIcon.getAttribute('aria-expanded') === 'true') {
          ordersAndReturnsIcon.classList.remove('unread');
          discussionMenu.classList.add('unread');
        }
      }
    }
  });

  const mutationObserver = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
      if (mutation.type === 'attributes' && mutation.attributeName === 'aria-expanded') {
        const isExpanded = ordersAndReturnsIcon.getAttribute('aria-expanded') === 'true';
        if (isExpanded) {
          const parent = ordersAndReturnsIcon.parentElement;
          const discussionsIcon = parent.querySelector('a[href="/discussions-with-buyers"]');
          if (ordersAndReturnsIcon.classList.contains('unread')) {
            ordersAndReturnsIcon.classList.remove('unread');
            discussionsIcon.classList.add('unread');
          }
        } else {
          if (ordersAndReturnsIcon.dataset.unread !== undefined) {
            ordersAndReturnsIcon.classList.add('unread');
            ordersAndReturnsIcon.querySelector('p').style.setProperty('background', 'none', 'important');
          }
        }
      }
    });
  });
  mutationObserver.observe(ordersAndReturnsIcon, { attributes: true, attributeFilter: ['aria-expanded'] }); 
  try {
    await sendMessage( { action: 'enableSchedule' });
  } catch (error) {
    toastMessage(`Błąd! ${error.message}`);
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  asyncOnMessageCallback(request, sender).then(resolved => { sendResponse({ success: true, result: resolved }) }).catch(rejected => { sendResponse({ success: false, result: rejected }) });
	return true;
});

async function asyncOnMessageCallback(request, sender) {
	const action = request.action;
  switch (action) {
    case 'updateIcon': {
      if (action === 'updateIcon') {
        let messageIcon, ordersAndReturnsIcon;
        try {
          [ messageIcon, ordersAndReturnsIcon ] = await waitForMenu();
        } catch (error) {
          toastMessage(`Błąd! ${error.message}`);
          return Promise.reject(false);
        }

        if (request.data.message.status === 'unread') {
          messageIcon.classList.add('unread');
          if (!request.data.message.silent) toastMessage('Masz nieprzeczytaną wiadomość.');
        } else {
          messageIcon.classList.remove('unread');
        }
        
        const drawer = document.querySelector('header[data-testid="drawer-menu"]');
        const drawerShow = (parseFloat(getComputedStyle(drawer).width) > 100);
        const discussionMenu = drawer.querySelector('a[href="/discussions-with-buyers"]');
        
        if (request.data.dispute.status === 'new' || request.data.dispute.status === 'unread') {
          ordersAndReturnsIcon.dataset.unread = true;
          if (drawerShow && ordersAndReturnsIcon.getAttribute('aria-expanded') === 'true') {
            discussionMenu.classList.add('unread');
          } else {
            ordersAndReturnsIcon.classList.add('unread');
            ordersAndReturnsIcon.querySelector('p').style.setProperty('background', 'none', 'important');
          }
          if (request.data.dispute.status === 'new') toastMessage('Masz nową wiadomość w dyskusji.');
        } else {
          ordersAndReturnsIcon.classList.remove('unread');
          delete ordersAndReturnsIcon.dataset.unread;
          discussionMenu?.classList.remove('unread');
        }
      }
      break;
    }
    case 'toast': {
      toastMessage(request.message);
      break;
    }
  }
}

async function waitForMenu(retry = 10) {
  let messageIcon = document.querySelector('a[href="/message-center/messages"]');
  let ordersAndReturnsIcon = document.querySelector('button[aria-controls="ordersAndReturns"]');

  if (!messageIcon || !ordersAndReturnsIcon) {
    if (--retry) {
      const delay = t => new Promise(resolve => setTimeout(resolve, t));
      await delay(5000);
      return await waitForMenu(retry);
    } else {
      return Promise.reject(new Error('Nie znaleziono menu bocznego. Rozszerzenie nie będzie działać.'));  
    }
  } else {
    return Promise.resolve([messageIcon.parentElement, ordersAndReturnsIcon]);
  }
}